#!bin/bash

awk -F" " '/02:00:00 PM/ {print $1, $2, $5, $6}' 0315_Dealer_schedule  >> Dealers_working_during_losses
